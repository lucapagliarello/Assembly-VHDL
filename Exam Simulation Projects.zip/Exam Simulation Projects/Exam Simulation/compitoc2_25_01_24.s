; Esercizio 4 Compito C2

;int elabora(char *a0, int n, int a2)
;{int i,c;
;
;  c=0;  
; 	
;  for(i=0;i<n;i++) 
;   { 
;   	 if (a0[i]<48 || a0[i] >= 58) 
;		return -1 ; 
;	 else if(a0[i]-48 < a2)
;	   	c++;		
;   } 
;
; return c;
;}

;main() {
;  char STR[16];
;  int i, a2, ris;     
   	
;     for(i=0; i<4;)
;     {
;	printf("Inserisci una stringa con solo numeri\n");
;      	scanf("%s",STR);	
;      	printf("Inserisci un numero ad una cifra\n");
;      	scanf("%d",&a2);
;	ris= elabora(STR,strlen(STR),a2);       
;    	printf("%d Ris = %d\n", i, ris);
;	if(ris>=0)	 
;   	    i++; 
;     } 
;} 
.data
; messaggi da visualizzare
msg1: .asciiz "Inserisci una stringa con solo numeri"
msg2: .asciiz "Inserisci un numero ad una cifra"
msg3: .asciiz "%d Ris = %d \n"

; parametri della syscall 5
p1s5: .space 8
i: .space 8
ris: .space 8

; parametri della syscall 3
fd: .byte 0
ind: .space 8
dim: .byte 16

STR: .space 16

.code
;     for(i=0; i<4;)
	daddi $s0, r0, 0  ;i = 0
for:	slti $t0, $s0, 4 
	beq $t0, $0, fine
;     {
;	printf("Inserisci una stringa con solo numeri\n");
	daddi $t1, $0, msg1
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
;      	scanf("%s",STR);	
	daddi $a0, $0, STR
	sd $a0, ind($0)
	daddi r14, $0, fd
	syscall 3
	move $a1, r1
;      	printf("Inserisci un numero ad una cifra\n");
	daddi $t1, $0, msg2
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
;      	scanf("%d",&a2);
	jal input_unsigned
	move $a2, r1
;	ris= elabora(STR,strlen(STR),a2);     
	jal elabora  
	dadd $s1, r1, r0
;    	printf("%d Ris = %d\n", i, ris);
	sd $s0, i($0)
	sd $s1, ris($0)
	daddi $t2, $0, msg3
	sd $t2, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5	
;	if(ris>=0)	 
if:	slti $t3, $s1, 0
	beq $t3, $0, for
	daddi $s0, $s0, 1	    ;i++; 
	j for

fine:	syscall 0

;int elabora(char *a0, int n, int a2)
elabora:	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)

	daddi $s1, $0, 0  ; $s1=c=0

;  for(i=0;i<n;i++)
	daddi $s0, $0, 0  ; $s0 = i = 0
for_e:	slt $t0, $s0, $a1
	beq $t0, $0, return
;   	 if (a0[i]<48 || a0[i] >= 58) 
	dadd $t0, $s0, $a0  ;$t0 = &a0[i]
	lbu $t2, 0($t0)
ifmin48: 	slti $t0, $t2, 48
	bne $t0, $0, returnmeno1
ifmag58: slti $t0, $t2, 58
	bne $t0, $0, returnmeno1

;	 else if(a0[i]-48 < a2)
elseif:	daddi $t2, $t2, -48
	slt $t0, $t2, $a2
	beq $t0, $0, incr_i
	daddi $s1, $s1, 1	;c++;		
;   } 

incr_i:	daddi $s0, $s0, 1
	j for_e

;return -1 ; 
returnmeno1: daddi r1, $0, -1
	         j ripristino

; return c;
return:	dadd r1, $0, $s1

ripristino: ld $s0, 0($sp)
	 ld $s1, 8($sp)
	 daddi $sp, $sp, 16
	 jr $ra

.include input_unsigned.s
