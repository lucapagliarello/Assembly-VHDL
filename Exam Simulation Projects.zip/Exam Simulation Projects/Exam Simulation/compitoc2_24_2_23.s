;int processa(char *s, int dim) 
;{int j,somma; 
 
;    somma=0; 
 ;   for(j=0;j<dim;j++) 
;       somma= somma+ s[j]%16;  
       
 ;  return somma; 
; } 
 
;main() { 
;  char ST[32]; 
;  int i,num,val;      
    
;  for(i=0;i<3;) 
;   { 
;    printf("Inserisci un numero >0 e <=16\n"); 
;    scanf("%d",&num); 
;    if(num!=0) 
;     {  printf("Inserisci una stringa con almeno %d caratteri\n",num); 
;        scanf("%s",ST); 
;        if(strlen(ST)>=num)  
;   { 
;      val= processa(ST,strlen(ST));        
;              printf(" Valore= %d \n",val);  
;              i++; 
;           } 
;     }  
;   } 
;}} 
.data
ST: .space 32

m1: .asciiz "Inserisci un numero >0 e <=16\n"
m2: .asciiz "Inserisci una stringa con almeno %d caratteri\n"
m3: .asciiz " Valore= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 32

.code
;  for(i=0;i<3;)

	daddi $s0, $0, 0 ; i = $s0 = 0
for_m:
	slti $t0, $s0, 3
	beq $t0, $0, fine

;    printf("Inserisci un numero >0 e <=16\n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
 
;    scanf("%d",&num); 

	jal input_unsigned
	move $s1, r1  ; $s1 = num

;    if(num!=0) 

	beq $s1, $0, for_m

;     {  printf("Inserisci una stringa con almeno %d caratteri\n",num); 

	sd $s1, val($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;        scanf("%s",ST); 

	daddi $a0, $0, ST
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1  ; $a1 = strlen(ST)
	daddi $a1, $a1, 1

;        if(strlen(ST)>=num)  -> if(num <= strlen(ST)) -> if(num < strlen(ST) + 1)

	slt $t0, $s1, $a1
	beq $t0, $0, for_m

;      val= processa(ST,strlen(ST));   

	jal processa
     
;              printf(" Valore= %d \n",val);  

	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

	daddi $s0, $s0, 1  ;i++; 
	j for_m

fine:
	syscall 0

;int processa(char *s, int dim) 
processa:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	
	daddi $s0, $0, 0 ;    somma=0; 

 ;   for(j=0;j<dim;j++)
	daddi $s1, $0, 0 ; j=0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;       somma= somma+ s[j]%16; 

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	li $t2, 16
	ddiv $t1, $t2
	mfhi $t3
	dadd $s0, $s0, $t3 
       
incr_f:
	daddi $s1, $s1, 1
	j for_f

 ;  return somma; 
return:
	move r1, $s0
	daddi $sp, $sp, 16
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	jr $ra

.include input_unsigned.s
