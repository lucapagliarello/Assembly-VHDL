; int calcola(char *st, int d, int val) 
; { int j,cnt; 
 
;     cnt=0; 
;     for(j=0;j<d;j++) 
;      if(st[j]-48<val) 
;   cnt++; 
;   else cnt+=2;  
;        
;    return cnt; 
; } 
 
; main() { 
; char ST[16]; 
;   int i,num,ris;      
    
;    i=0; 
;    do{ 
;     printf("Inserisci una stringa di soli numeri\n"); 
;     scanf("%s",ST); 
;     printf("Inserisci un numero a una cifra"); 
;     scanf("%d",&num); 
;     ris= calcola(ST,strlen(ST),num);        
;     printf(" Valore= %d \n",ris);  
;     i++; 
;   }  while(i<3); 
; } 
.data
ST: .space 16

m1: .asciiz "Inserisci una stringa di soli numeri\n"
m2: .asciiz "Inserisci un numero a una cifra"
m3: .asciiz " Valore= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 16

.code
	daddi $s0, $0, 0	;    i=0; 
;    do
do_while:

;     printf("Inserisci una stringa di soli numeri\n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;     scanf("%s",ST); 

	daddi $a0, $0, ST
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1

;     printf("Inserisci un numero a una cifra"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
	
;     scanf("%d",&num); 

	jal input_unsigned
	move $a2, r1

;     ris= calcola(ST,strlen(ST),num);      

	jal calcola
  
;     printf(" Valore= %d \n",ris); 

	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5	
 
	daddi $s0, $0, 0	;     i++; 
;   }  while(i<3); 
	slti $t0, $s0, 3
	bne $t0, $0, do_while

fine:
	syscall 0

; int calcola(char *st, int d, int val) 
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
 
	daddi $s0, $0, 0	;     cnt=0; 

;     for(j=0;j<d;j++)

	daddi $s1, $0, 0
for:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;      if(st[j]-48<val) 

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	daddi $t1, $t1, -48

	slt $t0, $t1, $a2
	beq $t0, $0, else

	daddi $s0, $s0, 1	;   cnt++; 
	j incr_i

;   else cnt+=2;  
else:
	daddi $s0, $s0, 2

incr_i:
	daddi $s1, $s1, 1
	j for	

;    return cnt; 
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	daddi $sp, $sp, 16
	jr $ra

.include input_unsigned.s
