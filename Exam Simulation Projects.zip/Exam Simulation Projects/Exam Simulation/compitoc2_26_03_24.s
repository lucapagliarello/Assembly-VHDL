;int processa(char *st0, char *st1, int n)
;{int i,c;
;  c=0;  
;  for(i=0;i<n;i++) 
;   { 
;     if(st0[i]==st1[i]) 
;         c++;
;     else if (st1[i]<st0[i])
;	 	   c+=2;		
;   } 
;return c;
;}

;main() {
;  char STR1[16], STR2[16];
;  int i, a2, ris;     
;  for(i=0;i<3;i++)
;   {
;    printf("Inserisci la prima stringa \n");
;    scanf("%s",STR1);	
;    printf("Inserisci una stringa con almeno %d caratteri\n",strlen(STR1));
;    scanf("%s",STR2);
;    if(strlen(STR1)<=strlen(STR2))
;     {
;      a2=strlen(STR1);
;	 ris= processa(STR1,STR2,a2);
;	}
;    else  ris=-1;		  	
;    printf("Ciclo %d:  Ris = %d\n", i, ris);
;   } 
;}
.data
STR1: .space 16
STR2: .space 16

m1: .asciiz "Inserisci la prima stringa \n"
m2: .asciiz "Inserisci una stringa con almeno %d caratteri\n"
m3: .asciiz "Ciclo %d:  Ris = %d\n"

;syscall 5
p1s5: .space 8
val1: .space 8
val2: .space 8

;syscall 3
p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;  for(i=0;i<3;i++)
	daddi $s0, $s0, 0  ; i = $s0 = 0
for_m:
	slti $t0, $s0, 3
	beq $t0, $0, fine
;    printf("Inserisci la prima stringa \n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;    scanf("%s",STR1);	

	daddi $a0, $0, STR1
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a2, r1  ; $a2 = strlen(STR1)

;    printf("Inserisci una stringa con almeno %d caratteri\n",strlen(STR1));

	sd $a2, val1($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;    scanf("%s",STR2);

	daddi $a1, $0, STR2
	sd $a1, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a3, r1  ; $a3 = strlen(STR2)

;    if(strlen(STR1)<=strlen(STR2))
if_m:
	slt $t0, $a2, $a3
	beq $t0, $0, else
;      a2=strlen(STR1);
;	 ris= processa(STR1,STR2,a2)}
	jal processa
	dadd $t0, $0, r1
	sd $t0, val2($0)
	j printf_Ris

;    else  ris=-1;	
else:
	daddi $t0, $0, -1
	  	
;    printf("Ciclo %d:  Ris = %d\n", i, ris);	
printf_Ris:
	sd $s0, val1($0)
	sd $t0, val2($0)
	daddi $t1, $0, m3
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1 ;i++
	j for_m
fine:
	syscall 0

;int processa(char *st0, char *st1, int n)
processa:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	daddi $s0, $0, 0	;  c=0;  

;  for(i=0;i<n;i++)
	daddi $s1, $0, 0  ;i = 0
for_f:
	slt $t0, $s1, $a2
	beq $t0, $0, return

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)  ; $t1 = st0[i]
	
	dadd $t0, $a1, $s1
	lbu $t2, 0($t0)  ; $t2 = st1[i]

;     if(st0[i]==st1[i]) 
if_f:
	bne $t1, $t2, else
	daddi $s0, $s0, 1	;         c++;
	j incr_i_f
;     else if (st1[i]<st0[i])
else:
	slt $t3, $t2, $t1
	beq $t3, $0, incr_i_f
	daddi $s0, $s0, 2;   c+=2;		

incr_i_f:
	daddi $s1, $s1, 1 ; i++
	j for_f
;return c;	
return:
	dadd r1, $0, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	daddi $sp, $sp, 16
	jr $ra	
