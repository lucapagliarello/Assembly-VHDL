;int calcola(char *s, int p)
;{int j,cnt, r;
; char c;
;  cnt=0;  
;  for(j=0;j<p;j++)
;    {r=s[j]/16;
;	 if(r<4)
;	     cnt++;
;    }
;  return cnt; 	
;} 

;main() {
;  char STRING[16];
;  int i, n, ris;     
;     for(i=0; i<3;i++)
;     {
;      printf("Inserisci un numero \n");
;      scanf("%d",&n);
;      n=n%10;
;	  do {
;	  printf("Inserisci una stringa con almeno %d caratteri\n",n);
;      scanf("%s",STRING);
;      } while (strlen(STRING)<n);
	  	
;      ris= calcola(STRING,n);           	   
;     printf("Risultato stringa %d = %d\n", (i+1), ris)	;   	  	   
;     } 
;}
.data
STRING: .space 16

;messaggi
m1: .asciiz "Inserisci un numero \n"
m2: .asciiz "Inserisci una stringa con almeno %d caratteri\n"
m3: .asciiz "Risultato stringa %d = %d\n"

;parametri syscall 5
p1s5: .space 8
val1: .space 8
val2: .space 8

;parametri syscall 3
p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;     for(i=0; i<3;i++)
	daddi $s0, $s0, 0  ; $s0 = i = 0
for_m:	
	slti $t0, $s0, 3
	beq $t0, $0, fine
;      printf("Inserisci un numero \n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;      scanf("%d",&n);

	jal input_unsigned
	move $s1, r1

;      n=n%10;

	daddi $t0, $0, 10
	ddiv $s1, $t0
	mfhi $s1

;	  do {printf("Inserisci una stringa con almeno %d caratteri\n",n);
do:
	sd $s1, val1($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
;      scanf("%s",STRING);

	daddi $a0, $0, STRING
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3

;      } while (strlen(STRING)<n);

	slt $t1, r1, $s1
	bne $t0, $0, do
	  	
;      ris= calcola(STRING,n);         

	dadd $a1, $0, $s1
	jal calcola
  	   
;     printf("Risultato stringa %d = %d\n", (i+1), ris)	;

	daddi $t0, $s0, 1
	sd $t0, val1($0)
	sd r1, val2($0)
	daddi $t1, $0, m3
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

;int calcola(char *s, int p)
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)

	daddi $s0, $0, 0  ; cnt = $s0 = 0  
;  for(j=0;j<p;j++)
	daddi $s1, $0, 0	; j = $s1 = 0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return
;    {r=s[j]/16;
	dadd $t1, $a0, $s1
	lbu $t2, 0($t1)  ; $t2 = s[j]
	dsra $t2, $t2, 4  ; $t2 = r = s[j]/16
;	 if(r<4)
if:	
	slti $t3, $t2, 4
	beq $t3, $0, incr_j
	daddi $s0, $s0, 1 ;   cnt++;

incr_j:
	daddi $s1, $s1, 1
	j for_f
;  return cnt; 	
return:	
	dadd r1, $0, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	daddi $sp, $sp, 16
	jr $ra

.include input_unsigned.s
