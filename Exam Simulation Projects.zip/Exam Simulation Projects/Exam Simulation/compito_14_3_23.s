; int esegui(char *s, int d) 
; { int i,t,c; 
 
;  t=0; 
;  c=0; 
;  for(i=0;i<d;i++) 
;      if(s[i]<58) 
;   { 
;     t=t+s[i]-48; 
;     c++;  
;   }   
;    if(c<4) return -1;           
;    else return t; 
; } 
 
; main() { 
;   char NUM[16]; 
;   int i,num,valore;      
    
;    for(i=0;i<4;i++)  
;      {printf("Inserisci una stringa con almeno 4 numeri\n");  
;       scanf("%s",NUM); 
      
;   valore= esegui(NUM,strlen(NUM));  
;   if(valore !=-1) 
 ;        printf(" Valore= %d \n",valore);  
;     
;      }     
; } 
.data
NUM: .space 16

m1: .asciiz "Inserisci una stringa con almeno 4 numeri\n"
m2: .asciiz " Valore= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;    for(i=0;i<4;i++)

	daddi $s0, $0, 0
for_m:
	slti $t0, $0, 4
	beq $t0, $0, fine
  
;      {printf("Inserisci una stringa con almeno 4 numeri\n");  

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;       scanf("%s",NUM); 

	daddi $a0, $0, NUM
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1  ; $a1= strlen(NUM)
      
;   valore= esegui(NUM,strlen(NUM));  

	jal esegui

;   if(valore !=-1) 
	
	li $t0, 1
	beq r1, $t0, incr_i

 ;        printf(" Valore= %d \n",valore);  

	sd r1, val($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

; int esegui(char *s, int d) 
esegui:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp)

	daddi $s0, $0, 0	;  t=0; 
	daddi $s1, $0, 0	;  c=0; 

;  for(i=0;i<d;i++)

	daddi $s2, $0, 0
for_f:
	slt $t0, $s2, $a1
	beq $t0, $0, if

;      if(s[i]<58) 

	dadd $t0, $a0, $s2	
	lbu $t1, 0($t0)
	slti $t0, $t1, 58
	beq $t0, $0, incr_f

;     t=t+s[i]-48; 

	daddi $t1, $t1, -48
	dadd $s0, $s0, $t1

	daddi $s1, $s1, 1	;     c++;  

incr_f:
	daddi $s2, $s2, 1
	j for_f
;    if(c<4) return -1; 
if:
	slti $t0, $s1, 4
	beq $t0, $0, else  
	daddi $s0, $0, -1 ; t=-1
	move r1, $s0
	j ripristina

else:
	move r1, $s0

 
ripristina:
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp)		
	daddi $sp, $sp, 24
	jr $ra