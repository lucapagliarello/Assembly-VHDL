; int calcola(char *s, int d,int num) 
; { int j,f;  
; if(num==1) return 1;  
; f=1; 
;      for(j=0;j<d;j++) 
;           if(s[j] -48 < num ) 
;    f=f*(s[j]-48);    
;    return f; 
; } 
 
; main() { 
;   char NUM[8]; 
 ;  int i,val,ris;         
 ;   printf("Inserisci una stringa di soli numeri \n"); 
 ;     scanf("%s",NUM); 
;      for(i=0; i<strlen(NUM);i++) 
;      {
;      printf("Inserisci un numero ad una cifra"); 
;      scanf("%d",&val);     
;      ris= calcola(NUM, strlen(NUM),val);            
;  printf(" Valore= %d \n",ris);  
;   }  
; }
.data
NUM: .space 8

;messaggi
m1: .asciiz "Inserisci una stringa di soli numeri \n"
m2: .asciiz "Inserisci un numero ad una cifra"
m3: .asciiz " Valore= %d \n"

;syscall 3
p1s3: .word 0
ind: .space 8
dim: .word 8

;syscall 5
p1s5: .space 8
val: .space 8

.code
 ;   printf("Inserisci una stringa di soli numeri \n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5 

 ;     scanf("%s",NUM);

	daddi $a0, $0, NUM
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $s1, r1  ; $s1 = strlen(NUM)

;      for(i=0; i<strlen(NUM);i++)

	daddi $s0, $0, 0  ; $s0 = i = 0
for_m:
	slt $t0, $s0, $s1
	beq $t0, $0, fine

;      printf("Inserisci un numero ad una cifra"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5 

;      scanf("%d",&val);    

	jal input_unsigned
	move $s2, r1  ;$s2 = val
 
;      ris= calcola(NUM, strlen(NUM),val);  

	daddi $a0, r0, NUM
	move $a1, $s1 ;strlen(NUM)
	move $a2, $s2 ;val
	jal calcola
	move $s3, $v0 ;ris = calcola
          
;  printf(" Valore= %d \n",ris);  

	sd $s3, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1 ;i++
	j for_m	

fine:
	syscall 0

calcola:
	
.include input_unsigned.s
