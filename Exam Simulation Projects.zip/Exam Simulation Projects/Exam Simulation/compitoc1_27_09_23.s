;int elabora(char *s,
;int d)
;{ int i,t,c;
;if(d<2) return -1;
;t=0;
;for(i=0;i<d 1;i++)
;if(s[i]==s[i+1])
;t++;
;return t;
;}
;main() {
;char STR[32];
;char *a0;
;int i,a1,ris;
;for(i=0;i<3; i++)
;do {
;	printf("%d) Inserisci una stringa con almeno 2 caratteri \n",i);
;	scanf("%s",STR);
;	a1=strlen(STR);
;	a0=STR;
;	ris=elabora(a0,a1);
;	printf(" Valore= %d \n",ris);
;}while(ris<0);
;}
.data
STR: .space 32

;messaggi
m1: .asciiz "%d) Inserisci una stringa con almeno 2 caratteri \n"
m2: .asciiz " Valore= %d \n"

;parametri syscall 3
par: .word 0
ind: .space 8
num_byte: .word 32

;parametri syscall 5
par1sys5: .space 8
val: .space 8

.code
;for(i=0;i<3; i++)
daddi $s0, $s0, 0  ;i=0
for:	slti $t1, $s0, 3
	beq $t1, $0, end_for

;do {
do:	sd $s0, val($0)
;	printf("%d) Inserisci una stringa con almeno 2 caratteri \n",i);

	la $t0, m1
	sd $t0, par1sys5($0)
	la r14, par1sys5
	syscall 5

;	scanf("%s",STR);
	
	la $a0, STR ; a0=STR;
	sd $a0, ind($0)
	la r14, ind
	syscall 3
;	a1=strlen(STR);
	move $a1, r1

;	ris=elabora(a0,a1);

	jal elabora
	move $t1, r1

;	printf(" Valore= %d \n",ris);
	
	sd r1, val($0)
	la $t0, m2
	sd $t0, par1sys5($0)
	la r14, par1sys5
	syscall 5
	
;}while(ris<0);

	slti $t2, $t0, 0
	bne $t2, $0, do	

incremento_i: daddi $s0, $s0, 1
	          j for
;}
end_for: syscall 0

;int elabora(char *s, ;int d)
elabora: daddi $sp, $sp, -8
	sd $s1, 0($sp)
	sd $s2, 8($sp)

;{ int i,t,c;
;if(d<2) return -1;

	slti $t0, $a1, 2   ;$t0 = 1 se d=$a1 < 2
	daddi r1, $0, -1
	beq $t0, $0, ripristina

	daddi $s2, $0, 0   ;t=0;
;for(i=0;i<d-1;i++)

	daddi $s1, $0, 0  ;i=0
	daddi $a1, $a1, -1	;d=d-1

forf:	slt $t0, $s1, $a1
	beq $t0, $0, return

;if(s[i]==s[i+1])
; &s[i] = s + i = $a0 + $s1
; &s[i+1] = s + i + 1 =  $a0 + $s1 + 1
	dadd $t0, $a0, $s1  ; $t0 = &s[i]
	lbu $t1, 0($t0)  ;s[i]
	lbu $t2, 1($t0)  ;s[i+1]
	bne $t1, $t2, incr_i
	daddi $s2, $s2, 1  ;t++;

incr_i:	daddi $s1, $s1, 1  ;i++
	          j forf
;return t;
return:	move r1, $s2 ;r1 = t

ripristina: ld $s1, 0($sp)
	 ld $s2, 8($sp)
	daddi $sp, $sp, 16
	jr r31
