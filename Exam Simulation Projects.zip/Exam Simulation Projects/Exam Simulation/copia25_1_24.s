; int processa(char *a0, char *a1) 
; {int j,c; 
 
;   c=0; 
;   j=0;   
;   while (a0[j]!=0 && a1[j]!=0) 
;    { 
;  if(a0[j] == a1[j])  
;   c++; 
;  j++; 
; }  
 
; return c; 
; } 
 
; main() { 
;   char ST1[16], ST2[16]; 
;   int i, ris;      
     
;      for(i=0; i<4;i++) 
;      { 
;    printf("Inserisci una stringa\n"); 
;        scanf("%s",ST1); 
         
;    printf("Inserisci una stringa\n"); 
;        scanf("%s",ST2); 
 
;        ris= processa(ST1,ST2);        
        
  
 ;  printf("%d – Ris = %d\n", i, ris) ;    
;      }  
; } 
.data
ST1: .space 16
ST2: .space 16

m1: .asciiz "Inserisci una stringa\n"
m2: .asciiz "%d – Ris = %d\n"

p1s5: .space 8
val1: .space 8
val2: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;      for(i=0; i<4;i++)

	daddi $s0, $0, 0
for_m:
	slti $t0, $s0, 4
	beq $t0, $0, fine

;    printf("Inserisci una stringa\n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
 
;        scanf("%s",ST1); 

	daddi $a0, $0, ST1
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3

         
;    printf("Inserisci una stringa\n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;        scanf("%s",ST2); 

	daddi $a1, $0, ST2
	sd $a1, ind($0)
	daddi r14, $0, p1s3
	syscall 3
 
;        ris= processa(ST1,ST2);     

	jal processa   
        
 ;  printf("%d – Ris = %d\n", i, ris) ;    

	sd $s0, val1($0)
	sd r1, val2($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

processa:
; {int j,c;
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
 
	daddi $s0, $0, 0	;   c=0; 
	daddi $s1, $0, 0	;   j=0;   

;   while (a0[j]!=0 && a1[j]!=0)
	
while:
	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	dadd $t0, $a1, $s1
	lbu $t2, 0($t0)

	beq $t1, $0, return

cond_2:
	beq $t2, $0, return

;  if(a0[j] == a1[j])  
	
	bne $t1, $t2, incr_j
	daddi $s0, $s0, 1	;   c++; 

;  j++; 
incr_j:
	daddi $s1, $s1, 1
	j while
	
; }  	
; return c; 
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	daddi $sp, $sp, 16
	jr $ra	
	
