; main() { 
; char STRINGA[16],*a0; 
; int i,a1,a2,valore;      
; for(i=0;i<4;i++) 
; {   
; printf("Inserisci una stringa di soli numeri con almeno 2 caratteri\n"); 
; scanf("%s",STRINGA); 
; if(strlen(STRINGA)>=2) 
; { printf("%d) Inserisci un numero maggiore di %d\n",i, strlen(STRINGA)); 
; scanf("%d",&a2); 
; a0= STRINGA; 
; a1=strlen(STRINGA); 
; valore=elabora(a0, a1,a2); 
; printf("%d Risultato = %d\n",i, valore); 
; }  
; } 
; } 
; int elabora(char *str, int a1, int a2) 
; { int i,s; 
; s=0; 
; for(i=0;i<a1;i++) 
; { 
; if(str[i]-48<0) // Esempio simboli ! # $ % & ( ) * + - / 
; return -1; 
; if(str[i]-48<a2 ) 
; s=s+str[i]-48; 
; } 
; return s;    
; }
.data
STRINGA: .space 16

m1: .asciiz "Inserisci una stringa di soli numeri con almeno 2 caratteri\n"
m2: .asciiz "%d) Inserisci un numero maggiore di %d\n"
m3: .asciiz "%d Risultato = %d\n"

p1s3: .word 0
ind: .space 8
dim: .word 16

p1s5: .space 8
val1: .space 8
val2: .space 8

.code
; for(i=0;i<4;i++)

	daddi $s0, $0, 0  ; i = $s0 = 0
for_m:
	slti $t0, $s0, 4
	beq $t0, $0, fine

; printf("Inserisci una stringa di soli numeri con almeno 2 caratteri\n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
 
; scanf("%s",STRINGA);

	daddi $a0, $0, STRINGA
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1  ; $a1 = strlen(STRINGA)
 
; if(strlen(STRINGA)>=2) 

if_m:
	slti $t0, $a1, 2
	bne $t0, $0, fine

; { printf("%d) Inserisci un numero maggiore di %d\n",i, strlen(STRINGA)); 

	sd $s0, val1($0)
	sd $a1, val2($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

; scanf("%d",&a2); 

	jal input_unsigned
	move $a2, r1

; a0= STRINGA; 

	

; a1=strlen(STRINGA); 



; valore=elabora(a0, a1,a2); 

	jal elabora
	
; printf("%d Risultato = %d\n",i, valore); 

	sd $s0, val1($0)
	sd r1, val2($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1  ; i++
	j for_m

fine:
	syscall 0

; int elabora(char *str, int a1, int a2) 
elabora:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)  ;i
	sd $s1, 8($sp)  ;s

	daddi $s1, $0, 0	; s=0;
 
; for(i=0;i<a1;i++)

	daddi $s0, $0, 0  ; i = 0
for_f:
	slt $t0, $s0, $a1
	beq $t0, $0, return

; if(str[i]-48<0) // Esempio simboli ! # $ % & ( ) * + - / 

	dadd $t0, $a0, $s0  ; $t0 = &str[i]
	lbu $t1, 0($t0)  ;$t1 = str[i]

; return -1; 

	li $t3, -1
	move r1, $t3
	j ripristina

; if(str[i]-48<a2 ) 
	
	daddi $t1, $t1, -48
if_f:
	slt $t2, $t1, $a2
	beq $t2, $0, incr_i_f

	dadd $s1, $s1, $t1	; s=s+str[i]-48; 

incr_i_f:
	daddi $s0, $s0, 1 ; i++
	j for_f

; return s;    
return:
	move r1, $s1
ripristina:
	ld $s0, 0($sp)  ;i
	ld $s1, 8($sp)  ;s
	daddi $sp, $sp, 16
	jr $ra	


.include input_unsigned.s
