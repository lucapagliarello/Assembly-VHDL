; int calcola(char *s, int d,int num) 
; {int j,p; 
;  
;   p=0; 
;   for(j=0;j<d;j++) 
;      if(s[j] % 2 == 0) 
;     p++;    
;  return p; 
; }
;  
; main() { 
 ;  char NUM[8]; 
 ;  int i,val,ris;      
 ;     
 ;     for(i=0; i<3;i++) 
  ;    { 
 ;   printf("Inserisci una stringa di soli numeri \n"); 
  ;      scanf("%s",NUM); 
      
  ;  printf("Quanti sono i numeri pari?"); 
   ;     scanf("%d",&val); 
     
   ;     ris= calcola(NUM, strlen(NUM),val);        
  ;      if(ris==val) 
 ;   printf(" Esatto, sono %d \n",ris); 
;   else printf("I numeri pari sono %d\n", ris) ;    
; }

.data
NUM: .space 8

m1: .asciiz "Inserisci una stringa di soli numeri \n"
m2: .asciiz "Quanti sono i numeri pari?"
m3: .asciiz " Esatto, sono %d \n"
m4: .asciiz "I numeri pari sono %d\n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 8

.code
 ;     for(i=0; i<3;i++)

	daddi $s0, $0, 0  ;i = $s0 = 0
for_m:
	slti $t0, $s0, 3
	beq $t0, $0, fine

 ;   printf("Inserisci una stringa di soli numeri \n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

  ;      scanf("%s",NUM); 

	daddi $a0, $0, NUM
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1
      
  ;  printf("Quanti sono i numeri pari?"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

   ;     scanf("%d",&val); 

	jal input_unsigned
	move $a2, r1
     
   ;     ris= calcola(NUM, strlen(NUM),val);     $a0 = NUM  $a1 = strlen(NUM) $a2 = val

	jal calcola ; r1 = ris
   
  ;      if(ris==val) 

	bne r1, $a2, else

 ;   printf(" Esatto, sono %d \n",ris); 

	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
	j incr_i

else:
;   else printf("I numeri pari sono %d\n", ris) ;    

	sd r1, val($0)
	daddi $t0, $0, m4
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1 ; i++
	j for_m

fine:
	syscall 0

; int calcola(char *s, int d,int num) 
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
  
	daddi $s0, $0, 0	;   p=0; 

;   for(j=0;j<d;j++)

	daddi $s1, $0, 0 ; j=0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;      if(s[j] % 2 == 0) 

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	li $t2, 2
	ddiv $t1, $t2
	mfhi $t3
	bne $t3, $0, incr_f

	daddi $s0, $s0, 1	;     p++;    

incr_f:
	daddi $s1, $s1, 1 ; j++
	j for_f

;  return p; 
return:
	move r1, $s0
	daddi $sp, $sp, 16
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	jr $ra	

.include input_unsigned.s
