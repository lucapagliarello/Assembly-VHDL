; int calcola(char *str, int a1, int num) 
; { int i,s,c; 
 
;    c=0; 
;    s=0; 
;    for(i=0;i<a1;i++) 
;     if(str[i]<58) 
;     {s=s+str[i]-48; 
;      c++; 
;       }  
   
;   if(c<2)   
;       return -1; 
;   else return s/num;            
;  
; } 
 
; main() { 
;   char STRINGA[32]; 
;   int i,a1,num,valore;      
    
;  for(i=0;i<4;i++) 
;   {   
;   printf("%d Inserisci una stringa con almeno 2 numeri\n",i); 
;   scanf("%s",STRINGA); 
;   a1=strlen(STRINGA); 
  
;   printf("%d) Inserisci un numero ad una sola cifra\n",i); 
;   scanf("%d",&num); 
 
;   valore= calcola(STRINGA, a1,num); 
   
;   if(valore!=-1) 
;       printf("%d Risultato = %d\n",i, valore); 
;   }   
; } 
.data
STRINGA: .space 32

m1: .asciiz "%d Inserisci una stringa con almeno 2 numeri\n"
m2: .asciiz "%d) Inserisci un numero ad una sola cifra\n"
m3: .asciiz "%d Risultato = %d\n"

p1s5: .space 8
val1: .space 8
val2: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 32

.code
;  for(i=0;i<4;i++)

	daddi $s3, $0, 0
for_m:
	slti $t0, $s3, 4
	beq $t0, $0, fine

;   printf("%d Inserisci una stringa con almeno 2 numeri\n",i); 

	sd $s3, val1($0)
	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   scanf("%s",STRINGA); 

	daddi $a0, $0, STRINGA
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3

	move $a1, r1 ;   a1=strlen(STRINGA); 
  
;   printf("%d) Inserisci un numero ad una sola cifra\n",i); 

	sd $s3, val1($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   scanf("%d",&num); 

	jal input_unsigned
	move $a2, r1
 
;   valore= calcola(STRINGA, a1,num); 

	jal calcola
   
;   if(valore!=-1) printf("%d Risultato = %d\n",i, valore); 

	li $t0, -1
	beq r1, $t0, incr_i

	sd $s3, val1($0)
	sd r1, val2($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
   
incr_i:
	daddi $s3, $s3, 1
	j for_m

fine:
	syscall 0 

; int calcola(char *str, int a1, int num) 
calcola:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp)
 
	daddi $s0, $0, 0	;    c=0; 
	daddi $s1, $0, 0	;    s=0; 

;    for(i=0;i<a1;i++)

	daddi $s2, $0, 0	; i=0;
for_f:
	slt $t0, $s2, $a1
	beq $t0, $0, if
 
;     if(str[i]<58) 

	dadd $t0, $a0, $s2
	lbu $t1, 0($t0)
	slti $t0, $t1, 58
	beq $t0, $0, incr_f

;     {s=s+str[i]-48; 

	daddi $t1, $t1, -48
	dadd $s1, $s1, $t1

	daddi $s0, $s0, 1	;      c++; 

incr_f:
	daddi $s2, $s2, 1
	j for_f

;   if(c<2) 
if:
	slti $t0, $s0, 2
	beq $t0, $0, else  
;       return -1; 
	daddi $t3, $0, -1
	j ripristina
;   else return s/num;       
else:
	
	ddiv $s1, $a2
	mflo $t3
     
ripristina:
	move r1, $t3
	daddi $sp, $sp, 24
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp)
	jr $ra

.include input_unsigned.s