; int calcola(char *st, int num) 
; { int i,ris,t; 
 
;    t=1; 
;    ris=0; 
;    for(i=0;i<num-1;i+=2) 
;     if(st[i]<st[i+1]) 
;   { 
;   t++; 
;   ris+=st[i]-48; 
;   } 
                  
;    return ris/t; 
; } 
 
; main() { 
;   char STRINGA[32]; 
;   char *a0; 
;   int i,a1,valore;      
   
;   for(i=0;i<4;i++) 
;   { 
;    do{ 
;      printf("Inserisci una stringa con un numero pari di caratteri\n"); 
;      scanf("%s",STRINGA); 
;      a1=strlen(STRINGA); 
;    }while (a1%2==1); 
   
;     a0=STRINGA; 
;   valore=  calcola(a0,a1); 
;  printf("Il risultato e' %d\n",valore); 
;   } 
; } 
.data
STRINGA: .space 32

m1: .asciiz "Inserisci una stringa con un numero pari di caratteri\n"
m2: .asciiz "Il risultato e' %d\n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 32

.code
;   for(i=0;i<4;i++) 

	daddi $s0, $0, 0 ; i=$s0=0
for_m:
	slti $t0, $s0, 4
	beq $t0, $0, fine

;    do{ 
do_while:

;      printf("Inserisci una stringa con un numero pari di caratteri\n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;      scanf("%s",STRINGA); 

	daddi $a0, $0, STRINGA
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3

	move $a1, r1	;      a1=strlen(STRINGA); 

;    }while (a1%2==1); 

	li $t0, 2
	ddiv $a1, $t0
	mfhi $t1
	li $t2, 1
	beq $t1, $t2, do_while 

   
;     a0=STRINGA; 
;   valore=  calcola(a0,a1); 

	jal calcola

;  printf("Il risultato e' %d\n",valore)

	sd r1, val($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

; int calcola(char *st, int num) 
calcola:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp)
 
	daddi $s0, $0, 1	;    t=1; 
	daddi $s1, $0, 0	;    ris=0; 

;    for(i=0;i<num-1;i+=2)

	daddi $s2, $0, 0 	; i=0
	daddi $a1, $a1, -1	; num = num - 1
for_f:
	slt $t0, $s2, $a1
	beq $t0, $0, return

;     if(st[i]<st[i+1]) 

	dadd $t0, $a0, $s2
	lbu $t1, 0($t0)
	lbu $t2, 1($t0)
	
	slt $t0, $t1, $t2
	beq $t0, $0, incr_f

	daddi $s0, $s0, 1	;   t++; 

;   ris+=st[i]-48; 

	daddi $t1, $t1, -48 ; st[i] = st[i] - 48
	dadd $s1, $s1, $t1 ; ris= ris + st[i] - 48
        
incr_f:
	daddi $s2, $s2, 2 ; i+=2
	j for_f
          
;    return ris/t; 
return:
	ddiv $s1, $s0
	mflo r1
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp)	
	daddi $sp, $sp, 24
	jr $ra
	
