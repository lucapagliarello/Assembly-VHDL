; int calcola(char *st, int d, int val)
; { int j,cnt; 
 
;     cnt=0; 
;     for(j=0;j<d;j++) 
;      if(st[j]-48==val) 
;   cnt++;  
;    return cnt; 
; } 
 
; main() { 
;   char ST[16]; 
;   int VAL[3]; 
;   int i,num;      
    
;  printf("Inserisci una stringa di soli numeri\n"); 
;     scanf("%s",ST); 
    
;    for(i=0;i<3;i++) 
;    { 
;     printf("Inserisci un numero a una cifra"); 
;     scanf("%d",&num); // usare input_unsigned 
;     VAL[i]= calcola(ST,strlen(ST),num);  
;  printf(" V[%d]= %d \n",i,VAL[i]);       
;    } 
;       
; } 
.data
ST: .space 16
VAL: .space 3

m1: .asciiz "Inserisci una stringa di soli numeri\n"
m2: .asciiz "Inserisci un numero a una cifra"
m3: .asciiz " V[%d]= %d \n"

p1s5: .space 8
val1: .space 8
val2: .space 8

p1s3: .word 0
ind: .space 8
dimST: .word 16
dimVAL: .word 3

.code
;  printf("Inserisci una stringa di soli numeri\n");

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;     scanf("%s",ST)

	daddi $a0, $0, ST
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1
    
;    for(i=0;i<3;i++)

	daddi $s0, $0, 0
for_m:
	slti $t0, $s0, 3
	beq $t0, $0, fine

;     printf("Inserisci un numero a una cifra"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;     scanf("%d",&num); // usare input_unsigned 

	jal input_unsigned
	move $a2, r1

;     VAL[i]= calcola(ST,strlen(ST),num);  

	jal calcola
	la $t0, VAL
	dadd $t1, $t0, $s0
	lbu $t2, 0($t1)
	move $t2, r1

;  printf(" V[%d]= %d \n",i,VAL[i]);

	sd $s0, val1($0)
	sd $t2, val2($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5       

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0   
; } 

; int calcola(char *st, int d, int val)
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp) 
 
	daddi $s0, $0, 0	;     cnt=0; 

;     for(j=0;j<d;j++)

	daddi $s1, $0, 0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;      if(st[j]-48==val) 

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	daddi $t1, $t1, -48
	bne $t1, $a2, incr_f

	daddi $s0, $s0, 1	;   cnt++;  

incr_f:
	daddi $s1, $s1, 1
	j for_f

;    return cnt; 
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp) 	 	
	daddi $sp, $sp, 16
	jr $ra

.include input_unsigned.s
