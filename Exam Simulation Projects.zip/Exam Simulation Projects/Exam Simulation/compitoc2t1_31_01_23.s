;int calcola(char *s) 
;{ int j,f,t; 
; f=0; 
; j=0; 
;     do { 
;   f=f+s[j]%10;  //resto della divisione per 10 
;   j++;   
; } while(s[j]!=48) ;     
;   return f; 
;} 
 
;main() { 
;  char VAL[8]; 
;  int i,num,ris;      
    
;   printf("Inserisci il numero di stringhe da leggere \n"); 
;   scanf("%d",&num); 
     
;     for(i=0; i<num;i++) 
;     { 
;      printf("Inserisci una stringa chiusa dal carattere 0\n"); 
;       scanf("%s",VAL); 
     
;      ris= calcola(VAL);        
     
;  printf(" Valore= %d \n",ris);  
;  }  
;} 
.data
VAL: .space 8

m1: .asciiz "Inserisci il numero di stringhe da leggere \n"
m2: .asciiz "Inserisci una stringa chiusa dal carattere 0\n"
m3: .asciiz " Valore= %d \n"

p1s3: .word 0
ind: .space 8
dim: .word 8

p1s5: .space 8
ris: .space 8

.code
;   printf("Inserisci il numero di stringhe da leggere \n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   scanf("%d",&num); 

	jal input_unsigned
	move $s1, r1  ; $s1 = num
     
;     for(i=0; i<num;i++) 

	daddi $s0, $0, 0  ; $s0 = i = 0
for_m:
	slt $t0, $s0, $s1
	beq $t0, $0, fine

;      printf("Inserisci una stringa chiusa dal carattere 0\n"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;       scanf("%s",VAL); 

	daddi $a0, $0, VAL
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
     
;      ris= calcola(VAL);        

	jal calcola
	daddi $s2, r1, 0  ; $s2 = ris
     
;  printf(" Valore= %d \n",ris);  

	sd $s2, ris($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

;int calcola(char *s) 
; s -> $a0
calcola:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp)

	daddi $s0, $0, 0  ; $s0 = f = 0
	daddi $s1, $0, 0  ; $s1 = j = 0

;     do { 
do:
	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)  ; $t1 = s[j]

	;   f=f+s[j]%10;  //resto della divisione per 10 
	li $t3, 10
	ddiv $t1, $t3
	mfhi $t5  ;$t5 = resto divisione
	dadd $s0, $s0, $t5
	
	daddi $s1, $s1, 1 ;j++;   

; } while(s[j]!=48) ;     
	
	li $t6, 48
	bne $t1, $t6, do

;   return f; 
return:
	move r1, $s0  ; r1 = $s0 = f

ripristina:
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp)
	daddi $sp, $sp, 24
	jr $ra	

.include input_unsigned.s