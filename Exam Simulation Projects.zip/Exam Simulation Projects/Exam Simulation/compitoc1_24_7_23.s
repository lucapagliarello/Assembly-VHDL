; int calcola(int a0, int a1) 
;{ int i,s,t; 
 
;   t=a0; 
;   s=0; 
;   for(i=0;i<a1;i++) 
;    {s=s+t; 
; t=t-1; 
;    } 
;                  
;   return s; 
;} 
 
;main() { 
;  char NUMERI[32]; 
;  int i,valore;      
;  int elem,num,dim;  
   
;  do{ 
;  printf("Inserisci una stringa di soli numeri con almeno numero 2 caratteri\n"); 
;  scanf("%s",NUMERI); 
;  dim=strlen(NUMERI); 
;  }while (dim<2); 
   
; for(i=0;i<dim;) 
;  { elem=NUMERI[i]-48;  
;    printf("%d) Inserisci un numero minore di %d\n",i,elem); 
;    scanf("%d",&num); 
;    if(num<elem) 
 ;  { 
;   valore=  calcola(elem,num); 
;   printf("Il risultato e’ %d\n",valore); 
;   i++;   
;    } 
;  }  
;} 
.data
NUMERI: .space 32

;messaggi
m1: .asciiz "Inserisci una stringa di soli numeri con almeno numero 2 caratteri\n"
m2: .asciiz "%d) Inserisci un numero minore di %d\n"
m3: .asciiz "Il risultato e’ %d\n"

;syscall 5
p1s5: .space 8
valore: .space 8
i: .space 8
elem: .space 8

;syscall 3
p1s3: .word 0
ind: .space 8
dim: .word 32

.code
;  do{
do_while:
	
;  printf("Inserisci una stringa di soli numeri con almeno numero 2 caratteri\n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;  scanf("%s",NUMERI); 

	daddi $a0, $0, NUMERI
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1	;  $a1 = dim = strlen(NUMERI); 

;  }while (dim<2); 
	
	slti $t0, $a1, 2
	bne $t0, $0, do_while
   
; for(i=0;i<dim;) 

	daddi $s0, $0, 0  ; $s0 = i = 0
for_m:
	slt $t1, $s0, $a1
	beq $t1, $0, fine

;  { elem=NUMERI[i]-48;  

	la $t0, NUMERI
	lbu $a0, 0($t0) ;$a0 = NUMERI[i]
	daddi $a2, $a0, -48 ; elem = $a2 = NUMERI[i] - 48

;    printf("%d) Inserisci un numero minore di %d\n",i,elem); 

	sd $s0, i($0)
	sd $a2, elem($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;    scanf("%d",&num); 

	jal input_unsigned
	move $a3, r1 ; $a3 = num

;    if(num<elem) 

if_m:
	slt $t0, $a3, $a2
	beq $t0, $0, for_m	

;   valore=  calcola(elem,num);

	jal calcola
 
;   printf("Il risultato e’ %d\n",valore); 

	sd r1, valore($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5	

	daddi $s0, $s0, 1	;   i++; 

fine:
	syscall 0

; int calcola(int a0, int a1) 
calcola:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)  ;i
	sd $s1, 8($sp)  ;s
	sd $s2, 16($sp)  ;t
	
	move $s2, $a0 ;   t=a0; 
	li $s2, 0 ;   s=0; 

;   for(i=0;i<a1;i++)

	li $s0, 0  ; i=0
for_f:
	slt $t0, $s0, $a1
	beq $t0, $0, return	

	dadd $s1, $s1, $s2 ;    s=s+t; 
	daddi $s2, $s2, -1 ; t=t-1; 
      
;   return s; 
return:
	move r1, $s1

ripristina:
	ld $s0, 0($sp)  ;i
	ld $s1, 8($sp)  ;s
	ld $s2, 16($sp)  ;t
	daddi $sp, $sp, 24
	jr $ra

.include input_unsigned.s
