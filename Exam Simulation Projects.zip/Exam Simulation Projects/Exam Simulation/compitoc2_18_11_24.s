; int elabora(char *a0, int a1) 
; { int s0,s1,t; 
 
;  s0=0; 
;  for(s1=0;s1<a1;s1++) 
;        { t=a0[s1]%a1; 
;          s0=s0+t; 
;        } 
;  return s0; 
; } 
 
; main() { 
;   char BUFFER[16]; 
;   char *a0; 
   
;   int s1,a1,r1;      
    
;    for(s1=0;s1<4;s1++ )  
;      { 
;     printf("STRINGA n. %d con almeno 4 caratteri\n",s1);  
;        scanf("%s",BUFFER); 
;        a0=BUFFER; 
;     a1=strlen(BUFFER); 
;     if(a1<4) 
;       printf("Stringa non valida\n"); 
;     else{ r1=elabora(a0,a1); 
;         printf(" Risultato= %d \n",r1);  
;            } 
;  }
.data
BUFFER: .space 16

m1: .asciiz  "STRINGA n. %d con almeno 4 caratteri\n"
m2: .asciiz "Stringa non valida\n"
m3: .asciiz " Risultato= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;    for(s1=0;s1<4;s1++)

	daddi $s1, $0, 0
for_m:
	slti $t0, $s1, 4
	beq $t0, $0, fine

;     printf("STRINGA n. %d con almeno 4 caratteri\n",s1); 

	sd $s1, val($0)
	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
 
;        scanf("%s",BUFFER); 
;        a0=BUFFER; 
;     a1=strlen(BUFFER); 

	daddi $a0, $0, BUFFER
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1

;     if(a1<4) 

	slti $t0, $a1, 4
	beq $t0, $0, else

;       printf("Stringa non valida\n"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
	j incr_i

;     else{ r1=elabora(a0,a1); 
;         printf(" Risultato= %d \n",r1);  
else:
	jal elabora
	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
	
incr_i:
	daddi $s1, $s1, 1
	j for_m

fine:
	syscall 0

; int elabora(char *a0, int a1) 
elabora:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp)
 
	daddi $s0, $0, 0	;  s0=0; 

;  for(s1=0;s1<a1;s1++)

for_f:
	daddi $s1, $0, 0
	slt $t0, $s1, $a1
	beq $t0, $0, return

;        { t=a0[s1]%a1; à

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	ddiv $t1, $a1
	mfhi $s2

	dadd $s0, $s0, $s2	;          s0=s0+t; 

;  return s0; 
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp)
	daddi $sp, $sp, 24
	jr $ra