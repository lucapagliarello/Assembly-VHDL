; calcola(char *s, int d) 
; { int i,t; 
 
;  t=0; 
;  for(i=0;i<d;i++) 
;      t=t+s[i];   
            
;    return t; 
; } 
 
; main() { 
;   char STR[24]; 
;   int i,num,ris;      
    
;    for(i=0;i<4;i++)  
   ;   { 
;      printf("Inserisci una stringa di numeri\n");  
;      scanf("%s",STR); 
;      if(strlen(STR)<2) 
;      { printf("Stringa troppo corta. Vuoi continuare? (1=Si,0=no)\n"); 
;      scanf("%d",&num); 
;    if(num==0)  
;         break;  
;  } 
;      else {ris= calcola(STR,strlen(STR));        
;            printf(" Risultato= %d \n",ris);  
;       } 
;  }  
; } 
.data
STR: .space 24

m1: .asciiz "Inserisci una stringa di numeri\n"
m2: .asciiz "Stringa troppo corta. Vuoi continuare? (1=Si,0=no)\n"
m3: .asciiz " Risultato= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 24

.code
;    for(i=0;i<4;i++)  

	daddi $s0, $0, 0
for_m:
	slti $t0, $s0, 4
	beq $t0, $0, fine

;      printf("Inserisci una stringa di numeri\n");  

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;      scanf("%s",STR); 

	daddi $a0, $0, STR
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1

;      if(strlen(STR)<2) 

	slti $t0, $a1, 2
	beq $t0, $0, else

;      { printf("Stringa troppo corta. Vuoi continuare? (1=Si,0=no)\n"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5	

;      scanf("%d",&num); 

	jal input_unsigned

;    if(num==0)  break;  
	beq r1, $0, fine
	j incr_i

;      else {ris= calcola(STR,strlen(STR));        
else:
	jal calcola

;            printf(" Risultato= %d \n",ris);  

	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5		

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

; calcola(char *s, int d)
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
 
	daddi $s0, $0, 0	;  t=0; 
;  for(i=0;i<d;i++)

	daddi $s1, $0, 0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;      t=t+s[i];   
            	
	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	dadd $s0, $s0, $t1

incr_f:
	daddi $s1, $s1, 1
	j for_f

;    return t; 
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	daddi $sp, $sp, 16
	jr $ra

.include input_unsigned.s
