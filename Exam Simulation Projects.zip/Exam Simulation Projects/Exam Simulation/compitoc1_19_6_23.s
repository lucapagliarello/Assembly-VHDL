;int esegui(char *s, int n) 
;{ int i,t; 
; 
;   t=0; 
;   for(i=0;i<n;i++) 
;    t=t+s[i]%4; 
;                  
;   return t; 
;} 
 
;main() { 
;  char STRINGA[8]; 
;  int i,valore;      
;  int num;  
;   
; i=0; 
;  while(i<3) 
;  { 
;    printf("Inserisci il numero minimo caratteri da inserire\n"); 
;    scanf("%d",&num); 
;    printf("Inserisci una stringa con almeno %d caratteri\n",num);  
;    scanf("%s",STRINGA); 
;      
;    if(strlen(STRINGA)<num) 
; {printf("Stringa di dimensione sbagliata. Fine esecuzione!\n"); 
;  i=3; 
;     } 
; 
; else {valore= esegui(STRINGA,num);        
;        printf(" Risultato= %d \n",valore);  
;     i++;  
;     }    
;  } 
;}
.data
STRINGA: .space 8

m1: .asciiz "Inserisci il numero minimo caratteri da inserire\n"
m2: .asciiz "Inserisci una stringa con almeno %d caratteri\n"
m3: .asciiz "Stringa di dimensione sbagliata. Fine esecuzione!\n"
m4: .asciiz " Risultato= %d \n"

p1s3: .word 0
ind: .space 8
dim: .word 8

p1s5: .space 8
val: .space 8

.code
	daddi $s0, $0, 0	; i=0; 

;  while(i<3)
while:
	slti $t0, $s0, 3
	beq $t0, $0, end_while

;    printf("Inserisci il numero minimo caratteri da inserire\n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;    scanf("%d",&num); 

	jal input_unsigned
	dadd $s1, $0, r1

;    printf("Inserisci una stringa con almeno %d caratteri\n",num);

	sd $s1, val($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
  
;    scanf("%s",STRINGA); 

	daddi $s2, $0, STRINGA
	sd $s2, ind($0)
	daddi r14, $0, p1s3
	syscall 3

	move $a1, r1  ; $a1 = strlen(STRINGA)

;    if(strlen(STRINGA)<num) 

	slt $t0, $a1, $s1
	beq $t0, $0, else

; {printf("Stringa di dimensione sbagliata. Fine esecuzione!\n"); 

	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

	daddi $s0, $0, 3	;  i=3; 
	j while 

; else {valore= esegui(STRINGA,num);    
else:
	;STRINGA = $s2
	;num = $s1
	j esegui	    
;        printf(" Risultato= %d \n",valore);  
;     i++;  
;     }    
;  } 
end_while:
	syscall 0

esegui:
	
.include input_unsigned.s
