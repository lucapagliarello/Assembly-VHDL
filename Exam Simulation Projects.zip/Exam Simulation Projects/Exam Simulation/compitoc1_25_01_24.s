; Esercizio 4 Compito C1
;int processa(char *a0, char *a1)
;{int j,c;
;  c=0;
;  j=0; 	
;  while (a0[j]!=0 && a1[j]!=0)
;   {
;	if(a0[j] == a1[j]) 
;		c++;
;	j++;
;  } 
; return c;
; }
;main() {
;  char ST1[16], ST2[16];
;  int i, ris;    
;     for(i=0; i<4;i++)
;     {
;	  printf("Inserisci una stringa\n");
;    	  scanf("%s",ST1); 	  	
;	  printf("Inserisci una stringa\n");
;   	  scanf("%s",ST2);
;    	  ris= processa(ST1,ST2);        	  
;            printf("%d – Ris = %d\n", i, ris)	;		 
;     } 
;}
.data
ST1: .space 16
ST2: .space 16

m1: .asciiz "Inserisci una stringa\n"
m2: .asciiz "%d – Ris = %d\n"

;parametri syscall 5
p1s5: .space 8
i: .space 8
ris: .space 8

;parametri syscall 3
p1s3: .word 0
inds3: .space 8
dims3: .word 16

.code
;     for(i=0; i<4;i++)
	daddi $s0, $0, 0  ; $s0 = i = 0
for_m:	slti $t0, $s0, 4
	beq $t0, $0, fine
;  	 printf("Inserisci una stringa\n");

	daddi $t1, $0, m1
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;    	  scanf("%s",ST1); 	  	

	daddi $a0, $0, ST1
	sd $a0, inds3($0)
	daddi r14, $0, p1s3
	syscall 3

;	  printf("Inserisci una stringa\n");

	daddi $t1, $0, m1
	sd $t1, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   	  scanf("%s",ST2);

	daddi $a1, $0, ST2
	sd $a1, inds3($0)
	daddi r14, $0, p1s3
	syscall 3

;    	  ris= processa(ST1,ST2);   

	jal processa
	dadd $s1, $0, r1
     	  
;                   printf("%d – Ris = %d\n", i, ris)	;		
	
	sd $s0, i($0)
	sd $s1, ris($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:	daddi $s0, $s0, 1 ;i++
	j for_m

fine: syscall 0

;int processa(char *a0, char *a1)
processa: daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	
	daddi $s0, $0, 0 ; c=0
	daddi $s1, $0, 0 ; j=0

;  while (a0[j]!=0 && a1[j]!=0)
while:
	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)  ;a0[j]
	beq $t1, $0, return
	
	dadd $t2, $a1, $s1
	lbu $t3, 0($t0)  ;a1[j]
	beq $t3, $0, return

;	if(a0[j] == a1[j]) 
	bne $t1, $t3, incr_j
	daddi $s0, $0, 0  ;c++

incr_j:	daddi $s1, $0, 0  ;j++
	j while

; return c;
return: 	dadd r1 $0, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	daddi $sp, $sp, 16
	jr $ra
