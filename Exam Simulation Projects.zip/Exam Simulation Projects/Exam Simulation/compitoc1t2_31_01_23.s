; int calcola(char *s, int d) 
; { int i,t; 
 
;  t=0; 
;  for(i=0;i<d;i++) 
;      t=t+s[i]/16;   
          
;    return t; 
; } 
;  
; main() { 
;   char STR[24]; 
;   int i,num,ris;      
    
;      do 
;      { 
;      printf("Inserisci una stringa \n");  
;      scanf("%s",STR); 
;      if(strlen(STR)<2) 
;      { 
;      printf("Inserisci un numero  \n"); 
;        scanf("%d",&ris); 
;   } 
;      else ris= calcola(STR,strlen(STR));        
; ;          
;      printf(" Risultato= %d \n",ris);  
;   } while (strlen(STR)>=2);  
; // Se la dimensione della stringa <2 il programma termina 
; } 
.data
STR: .space 24

m1: .asciiz "Inserisci una stringa \n"
m2: .asciiz "Inserisci un numero  \n"
m3: .asciiz " Risultato= %d \n"

p1s5: .space 8
val: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 24

.code
;      do { printf("Inserisci una stringa \n");  
do:
	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;      scanf("%s",STR); 

	daddi $a0, $0, STR
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3
	move $a1, r1

;      if(strlen(STR)<2) 

	slti $t0, $a1, 2
	beq $t0, $0, else

;      printf("Inserisci un numero  \n"); 

	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;        scanf("%d",&ris); 

	jal input_unsigned
	j printf
	
;   } 
;      else ris= calcola(STR,strlen(STR));       
else:

	jal calcola
	          
;      printf(" Risultato= %d \n",ris);  
printf:	
	
	sd r1, val($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5
		
;   } while (strlen(STR)>=2);  

	slti $t0, $a1, 2
	beq $t0, $0, do

fine:
	syscall 0

; int calcola(char *s, int d) 
calcola:
	daddi $sp, $sp, -16
	sd $s0, 0($sp)
	sd $s1, 8($sp)
 
	daddi $s0, $0, 0	;  t=0; 

;  for(i=0;i<d;i++)
	
	daddi $s1, $0, 0
for_f:
	slt $t0, $s1, $a1
	beq $t0, $0, return

;      t=t+s[i]/16;   

	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)
	srl $t0, $t1, 4
	dadd $s0, $s0, $t0

incr_f:
	daddi $s1, $s1, 1
	j for_f
          
;    return t;
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)	
	daddi $sp, $sp, 16
	jr $ra

.include input_unsigned.s
