; int calcola(char *s, int d, int n)
; {int j,cnt,incr ; 
   
;   cnt=0; 
;   incr=n/d; 
   
;   for(j=0;j<d;j++) 
;       if(s[j]-48<n) 
;       cnt=cnt+incr; 
  
;   return cnt;   
; }  
 
 
; main() { 
;   char STRING[16]; 
;   int i, n, len,ris;      
     
;      for(i=0; i<3;i++) 
;      { 
;   printf("Inserisci una stringa con almeno 4 caratteri \n"); 
;       scanf("%s",STRING); 
;       len=strlen(STRING); 
;       printf("Inserisci un numero maggiore o uguale a %d\n",len); 
;       scanf("%d",&n); 
;   if(n<len) 
;      n=len;  
;       ris= calcola(STRING,len,n);        
;       if(ris>0)     
;        printf("ciclo %d: Risultato = %d\n", i, ris) ; 
      
;      }  
; } 
.data
STRING: .space 16

m1: .asciiz "Inserisci una stringa con almeno 4 caratteri \n"
m2: .asciiz "Inserisci un numero maggiore o uguale a %d\n"
m3: .asciiz "ciclo %d: Risultato = %d\n"

p1s5: .space 8
val1: .space 8
val2: .space 8

p1s3: .word 0
ind: .space 8
dim: .word 16

.code
;      for(i=0; i<3;i++)

	daddi $s0, $0, 0 ; i = $s0 = 0
for_m:
	slti $t0, $s0, 3
	beq $t0, $0, fine

;   printf("Inserisci una stringa con almeno 4 caratteri \n"); 

	daddi $t0, $0, m1
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;       scanf("%s",STRING); 

	daddi $a0, $0, STRING
	sd $a0, ind($0)
	daddi r14, $0, p1s3
	syscall 3

	move $a1, r1	;       len=strlen(STRING); 

;       printf("Inserisci un numero maggiore o uguale a %d\n",len); 

	sd $a1, val1($0)
	daddi $t0, $0, m2
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;       scanf("%d",&n); 

	jal input_unsigned
	move $a2, r1

;   if(n<len)  n=len;  

	slt $t0, $a2, $a1
	beq $t0, $0, istruz
	move $a2, $a1	

;       ris= calcola(STRING,len,n);  
istruz:
	jal calcola	     
 
;       if(ris>0)   
	
	slti $t0, r1, 0  ; la condizione ris > 0 è vera quando ris < 0 è falsa
	bne $t0, $0, incr_i
	
;        printf("ciclo %d: Risultato = %d\n", i, ris) ; 

	sd $s0, val1($0)
	sd r1, val2($0)
	daddi $t0, $0, m3
	sd $t0, p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

incr_i:
	daddi $s0, $s0, 1
	j for_m

fine:
	syscall 0

; int calcola(char *s, int d, int n)
calcola:
	daddi $sp, $sp, -24
	sd $s0, 0($sp)
	sd $s1, 8($sp)
	sd $s2, 16($sp) 
   
	daddi $s0, $0, 0	;   cnt=0;
 
;   incr=n/d

	ddiv $a2, $a1
	mflo $s1
   
;   for(j=0;j<d;j++)

	daddi $s2, $0, 0
for_f:
	slt $t0, $s2, $a1
	beq $t0, $0, return

;       if(s[j]-48<n) 

	dadd $t0, $a0, $s2
	lbu $t1, 0($t0)
	daddi $t1, $t1, -48
	slt $t0, $t1, $a2
	beq $t0, $0, incr_f

	dadd $s0, $s0, $s1	;       cnt=cnt+incr; 

incr_f:
	daddi $s2, $s2, 1
	j for_f
 
;   return cnt;   
return:
	move r1, $s0
	ld $s0, 0($sp)
	ld $s1, 8($sp)
	ld $s2, 16($sp) 
	daddi $sp, $sp, 24
	jr $ra
	
.include input_unsigned.s
