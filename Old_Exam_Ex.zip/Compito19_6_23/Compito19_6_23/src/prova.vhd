library ieee;
use ieee.std_logic_1164.all	;

Entity CU is 
Port(	clk, start: in std_logic;  
		Op,ready: in std_logic;  
		conta: in integer range 0 to 3;  
		stato: out integer range 0 to 5 ); 
End CU;  

Architecture beh of CU is
signal st: integer range 0 to 5;
begin  			 
	process(st)	
	begin
		case st is	   
			when 0 =>
			if start = '0' then st <= 0;
			else
				st <= 1;
			end if;	
			
			when 1 =>
			if Op = '0' then st <= 2;
			else
				st <= 3;
			end if;
			
			when 2 =>
			if ready = '0' then st <= 4;
			else
				st <= 2;
			end if;
			
			when 3 =>
			if conta = 3 then st <= 5;
			else
				st <= 3;
			end if;
			
			when 4 => st <= 0;
			
			when 5 => st <= 0;
			
			when others => null;
		end case;
	end process;
	
	stato <= st;
	
end beh; 