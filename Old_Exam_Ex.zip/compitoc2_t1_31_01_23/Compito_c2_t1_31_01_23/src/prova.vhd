library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_signed.all;	  

Entity DP is 
Port(	clk, sel: in std_logic;  
		WRA,WRB,WRR: in std_logic;  
		Din: in std_logic_vector(15 downto 0); 
		R: out std_logic_vector(15 downto 0) ); 
End DP;  									  

Architecture beh of DP is
signal A, B, somma: std_logic_vector(15 downto 0);
begin  
	somma <= A + B;
	process(clk)
	begin
		if clk'event and clk = '0' then	 
			if WRA = '1' then	
				if sel = '0' then
					A <= Din;
				else
					A <= somma;
				end if;
			end if;	   
			
			if WRB = '1' then
				B <= Din;
			end if;
			
			if WRR = '1' then
				R <= somma;
			end if;
		end if;
	end process;
end beh; 