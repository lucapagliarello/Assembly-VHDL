----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 05.01.2025 16:38:36
-- Design Name: 
-- Module Name: compito_c2_25_01_24 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use ieee.std_logic_unsigned.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity compito_c2_25_01_24 is
Port(   clk,op: in std_logic;  
        WeA,WeC, selC: in std_logic;  
        Din: in std_logic_vector(7 downto 0); 
        R: out std_logic_vector(7 downto 0) ); 
end compito_c2_25_01_24;

architecture Behavioral of compito_c2_25_01_24 is
    signal A, risultato: std_logic_vector(7 downto 0);
    signal nconta, conta: integer range 0 to 2;
    signal WeR: std_logic;
begin
    risultato <= A + Din when op = '0' else A - Din;
    
    nconta <= 0 when selC = '0' else (conta + 1);
    
    WeR <= '1' when conta = 2 else '0';
    
    process(clk)
    begin
        if clk'event and clk = '0' then
            if WeA = '1' then A <= Din;
            end if;
            
            if WeC = '1' then conta <= nconta;
            end if;
            
            if WeR = '1' then R <= risultato;
            end if;
        end if;        
    end process;
end Behavioral;
