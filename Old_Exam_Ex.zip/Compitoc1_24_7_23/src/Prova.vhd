library ieee;
use ieee.std_logic_1164.all;

Entity CU is 
Port( 	op: in std_logic; 
		stato: in std_logic_vector(1 downto 0); 
		Sel, Exe1, Exe2, Write,Ready: out std_logic); 
End CU;  

Architecture beh of CU is  
begin
	Ready <= '1' when stato = "00" else '0';	  
	Sel <= '1' when op = '1' and (stato = "01" or stato = "10") else '0';
	Exe1 <= '1' when stato = "10" else '0';
	Exe2 <= '1' when stato = "11" else '0';
	Write <= '1' when stato = "10" or stato = "11" else '0';
end beh; 