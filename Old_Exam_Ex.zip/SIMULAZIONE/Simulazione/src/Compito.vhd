library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_signed.all;

Entity DP is 
Port(	clk, selR,op: in std_logic;  
		WRA,WRB,WRR: in std_logic;  
		Din: in std_logic_vector(7 downto 0); 
		R: out std_logic_vector(7 downto 0) ); 
End DP;  										  

Architecture beh of DP is
signal A,B, MuxRis, AluRis: std_logic_vector(7 downto 0);
begin
	AluRis <= A + B when op = '0' else A - B; 
	MuxRis <= AluRis when selR = '0' else A;
		
	process(clk)
	begin
		if falling_edge(clk) then
			if WRA = '1' then A <= Din;
			end if;
			
			if WRB = '1' then B <= Din;
			end if;
			
			if WRR = '1' then R <= MuxRis;
			end if;
			
		end if;
		
	end process;
	
end beh; 