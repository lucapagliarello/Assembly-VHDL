library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_signed.all;

Entity DP is 
Port(	clk,WA,WR: in std_logic; 
 		OP: in std_logic_vector(1 downto 0);  
 		I: in std_logic_vector(15 downto 0); 
 		R: out std_logic_vector(15 downto 0) ); 
End DP;  

Architecture beh of DP is
signal A, Ris: std_logic_vector(15 downto 0);
begin 	
	process(OP)
	begin
	case OP is
		when "00" => Ris <= A + I;
		when "01" => Ris <= A or I;
		when "10" =>
		if A < I then
			Ris <= A;
		else
			Ris <= I;
		end if;
		
		when "11" => Ris <= A and I;
		when others => null;
	end case; 
	end process;
	
	process(clk)
	begin
		if falling_edge(clk) then  
			if WA = '1' then A <= I;
			end if;
			
			if WR = '1' then R <= Ris;
			end if;
			
		end if;
	
	end process;
end beh;