----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 12.11.2024 15:52:32
-- Design Name: 
-- Module Name: Prova - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity CU is
    port( op: in std_logic;
          stato: in std_logic_vector(1 downto 0);
          EXEA, EXEB, WRA, WRB, Ready: out std_logic);
end CU;

architecture Behavioral of CU is
begin
    Ready <= '1' when stato <= "00" else '0';
    EXEA <= '1' when (stato <= "01" or stato <= "10") and op = '0' else '0';
    EXEB <= '1' when (stato <= "01" or stato <= "10") and op = '1' else '0';
    WRA <= '1' when stato <= "11" and op = '0' else '0';
    WRB <= '1' when stato <= "11" and op = '1' else '0';
    
end Behavioral;
