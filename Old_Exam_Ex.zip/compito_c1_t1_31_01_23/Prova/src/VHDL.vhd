library ieee;
use ieee.std_logic_1164.all;

Entity CU is 
	Port(	clk, start: in std_logic;  
			Op,ready: in std_logic;  
			stato: out std_logic_vector(2 downto 0) ); 
End CU;  				   

Architecture beh of CU is  	
signal st: std_logic_vector(2 downto 0);
begin
	process(clk)
	begin
		if falling_edge(clk) then 
			case st is
				when "000" =>
				if start = '1' then	 
					st <= "001";
				else
					st <= "000";
				end if;
				
				when "001" =>
				if ready = '0' then
					st <= "001";
				else
					st <= "010";	 
				end if;
				
				when "010" =>
				if Op = '0' then
					st <= "100";
				else
					st <= "011";
				end if;
				
				when "100" =>
					st <= "101";
				
				when "011" =>
					st <= "000";
				
				when "101" =>
					st <= "000";
				when others => null;
			end case;
		end if;
	end process;
end beh;