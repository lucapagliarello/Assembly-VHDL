;main() {
;  char STRINGA[16],*a0;
;  int i,a1,a2,valore;     
  
;  for(i=0;i<4;i++)
;  {  
;   printf("Inserisci una stringa di soli numeri con almeno 2 caratteri\n");
;   scanf("%s",STRINGA);
 
;   if(strlen(STRINGA)>=2)
;   { printf("%d) Inserisci un numero maggiore di %d\n",i, strlen(STRINGA));
;     scanf("%d",&a2);
;     a0= STRINGA;
;     a1=strlen(STRINGA);
;     valore=elabora(a0, a1,a2);
     
;     printf("%d Risultato = %d\n",i, valore);
;   } 
;  }
;}

;int elabora(char *str, int a1, int a2)
;{ int i,s;
 ;s=0;
 ;for(i=0;i<a1;i++)
 ;{
 ; if(str[i]-48<0) // Esempio simboli ! # $ % & ( ) * + - /
 ; 	 return -1;
 ; if(str[i]-48<a2 )
 ;   s=s+str[i]-48;
 ;}
; return s;   
;}
.data

STRINGA: .space 16

m1: .asciiz "Inserisci una stringa di soli numeri con almeno 2 caratteri\n"
m2: .asciiz "%d) Inserisci un numero maggiore di %d\n"
m3: .asciiz "%d Risultato = %d\n"

;parametri syscall 3
p1s3: .word 0
ind3: .space 8
dim3: .word 16


; parametri syscall 5
p1s5: .space 8   ; dobbiamo mettere l'indirizzo della stringa da stampare
val1: .space 8
val2: .space 8

.code

;  for(i=0;i<4;i++)
	daddi $s0, $0,0	; i=0
for: 	slti $t0, $s0, 4
	beq $t0, $0, fine
;  {  
;   printf("Inserisci una stringa di soli numeri con almeno 2 caratteri\n");
	daddi $t0, $0, m1
	sd $t0,p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   scanf("%s",STRINGA);
 	daddi $t0, $0, STRINGA  ;$t0= STRINGA;
	sd $t0, ind3($0)
	daddi r14, $0, p1s3
	syscall 3

	dadd $s1, $0, r1  ;$s1=strlen(STRINGA);

;   if(strlen(STRINGA)>=2) vero equivale a if(strlen(stringa)<2) falso
	slti $t0, $s1, 2  ; $t0=1 se strlen(STRINGA)<2, $t0=0 se strlen(STRINGA)>=2
	bne $t0, $0, incr_i ; se la condizione e' falsa andiamo a incrementare l'indice i   

;   { printf("%d) Inserisci un numero maggiore di %d\n",i, strlen(STRINGA));

	sd $s0, val1($0)
	sd $s1, val2($0)

	daddi $t0, $0, m2
	sd $t0,p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;     scanf("%d",&a2);
	jal input_unsigned
	dadd $a2, $0, r1

;     a0= STRINGA;
	daddi $a0, $0, STRINGA
;     a1=strlen(STRINGA);
	dadd $a1, $0, $s1

;     valore=elabora(a0, a1,a2);
     jal elabora


;     printf("%d Risultato = %d\n",i, valore);
	sd $s0, val1($0)
	sd r1, val2($0)

	daddi $t0, $0, m3
	sd $t0,p1s5($0)
	daddi r14, $0, p1s5
	syscall 5

;   } 
;  }

incr_i: 	daddi $s0, $s0, 1 ; i++
	      	 j for

;}
fine: syscall 0


;int elabora(char *str, int a1, int a2)
elabora: daddi $sp, $sp, -16
		sd $s0, 0($sp)
		sd $s1, 8($sp)

 ;s=0; $s0 -> s
 ;for(i=0;i<a1;i++)  $s1->i
 	daddi $s0, $0, 0 ;s=0;
;for(i=0;i<a1;i++)
	daddi $s1, $0, 0 ; i=0
forf: 	slt $t0, $s1, $a1
	beq $t0, $0, return
;{
 ; if(str[i]-48<0) // Esempio simboli ! # $ % & ( ) * + - /
 ; 	 return -1;

	;&str[i]= str+i=$a0+$s1	
	dadd $t0, $a0, $s1
	lbu $t1, 0($t0)	; $t1=str[i]
	daddi $t1, $t1, -48  ; $t1 = str[i]-48

	slti $t2, $t1, 0  ; $t2 = 1 se str[i]-48 < 0
	beq $t2, $0, altro_if	; se la condizione e' falsa passiamo all'if seguente

	daddi $s0, $0, -1 
	j return

 ; if(str[i]-48<a2 )
 ;   s=s+str[i]-48;
altro_if: slt $t2, $t1, $a2
	    beq $t2, $0, incr_i_f

	dadd $s0, $s0, $t1 ;     s=s+str[i]-48;



incr_i_f:   daddi $s1, $s1, 1  ; i++
	       j forf
 ;}

; return s;   

return:	dadd r1, $0, $s0
	 	ld $s0, 0($sp)
		ld $s1, 8($sp)
		daddi $sp, $sp, 16

		jr $ra
;}


.include input_unsigned.s
