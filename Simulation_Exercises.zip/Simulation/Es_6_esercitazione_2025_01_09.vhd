								 library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.std_logic_signed.all;

entity datapath is
    Port ( clk,selR, OP : in STD_LOGIC;
           WRA, WRB, WRR : in STD_LOGIC;
           Din : in STD_LOGIC_VECTOR (7 downto 0);
           R : out STD_LOGIC_VECTOR (7 downto 0));
end datapath;

architecture Behavioral of datapath is
signal A,B, Aris, MuxRis: std_logic_vector( 7 downto 0);
begin

ARis <= A + B when op='0' else A-B;

MuxRis <= A when selR = '0' else Aris;

process(clk)
begin
    if clk'event and clk='0' then
        if WRA = '1' then A <= Din;
        end if;
    	  if WRB <= '1' then B <= Din;
    	  end if;
        if WRR <= '1' then R <= MuxRis;
    	  end if;
                     
    end if;
    
end process;

end Behavioral;
